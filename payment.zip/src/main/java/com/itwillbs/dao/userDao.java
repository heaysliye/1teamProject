package com.itwillbs.dao;

import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class userDao {
	
	private SqlSessionTemplate sqlSessionTemplate;
	
	private static final String namespace="com.itwillbs.mappers.userMapper";
	
	@Inject
	public void paid(Map<String, Object> map) {
	    sqlSessionTemplate.update("user.paid", map);
	}

	public void rePaid(Map<String, Object> map) {
	    sqlSessionTemplate.update("user.rePaid", map);		
	}

	public String paidCheck(String ID) {
	    return sqlSessionTemplate.selectOne("user.paidCheck", ID);
	}
}
