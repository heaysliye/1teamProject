package com.itwillbs.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.itwillbs.dao.userDao;

@Service
public class UserService {
	userDao userDao;
	//Service
//	void paid(Map<String, Object> map) {
//	}
//
//	void rePaid(Map<String, Object> map) {
//	}
//
//	String paidCheck1(String ID) {
//		return ID;
//	}

	//ServiceImpl
	public void paid(Map<String, Object> map) {
	    userDao.paid(map);
	}

	public void rePaid(Map<String, Object> map) {
	    userDao.rePaid(map);		
	}

	public String paidCheck(String ID) {
	    return userDao.paidCheck(ID);
	}


}
